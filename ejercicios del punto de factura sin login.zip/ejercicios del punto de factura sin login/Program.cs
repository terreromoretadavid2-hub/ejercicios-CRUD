﻿// Punto de Venta simple - C# WinForms (compatible con el compilador de Windows)
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace PuntoDeVenta
{
    public class Product { public string C; public string N; public decimal Pr; public int St; }
    public class Sale { public DateTime D; public decimal Total; }
    public class Db { public List<Product> Products = new List<Product>(); public List<Sale> Sales = new List<Sale>(); }
    class Line { public Product P; public int Q; }

    class MainForm : Form
    {
        Db db = new Db();
        string file = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "PuntoDeVentaSimple.xml");
        List<Line> cart = new List<Line>();
        TextBox q, pc, pn, pp, ps; ListView lv, pv; Label lt, lh;

        static string M(decimal n) { return n.ToString("N2", CultureInfo.InvariantCulture); }
        static decimal Num(string s)
        {
            decimal v; return decimal.TryParse((s ?? "").Replace(",", "").Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out v) ? v : 0;
        }
        void Save() { using (var f = File.Create(file)) new XmlSerializer(typeof(Db)).Serialize(f, db); }
        Product Find(string c) { foreach (var p in db.Products) if (p.C.ToLower() == c.ToLower()) return p; return null; }

        static Button Btn(Control p, string t, int x, int y, int w, EventHandler h)
        { var b = new Button(); b.Text = t; b.Left = x; b.Top = y; b.Width = w; b.Height = 32; b.Click += h; p.Controls.Add(b); return b; }
        static TextBox Txt(Control p, string lab, int x, int w)
        {
            var l = new Label(); l.Text = lab; l.Left = x; l.Top = 8; l.AutoSize = true; p.Controls.Add(l);
            var t = new TextBox(); t.Left = x; t.Top = 30; t.Width = w; p.Controls.Add(t); return t;
        }
        static ListView LV(params string[] cols)
        {
            var v = new ListView(); v.View = View.Details; v.FullRowSelect = true; v.GridLines = true; v.HideSelection = false; v.MultiSelect = false;
            foreach (var c in cols) { var a = c.Split(':'); var h = new ColumnHeader(); h.Text = a[0]; h.Width = int.Parse(a[1]); if (a.Length > 2) h.TextAlign = HorizontalAlignment.Right; v.Columns.Add(h); }
            return v;
        }

        public MainForm()
        {
            try { if (File.Exists(file)) using (var f = File.OpenRead(file)) db = (Db)new XmlSerializer(typeof(Db)).Deserialize(f); } catch { }
            if (db.Products.Count == 0)
            {
                db.Products.Add(new Product { C = "1001", N = "Agua 500ml", Pr = 35, St = 100 });
                db.Products.Add(new Product { C = "1002", N = "Refresco 20oz", Pr = 60, St = 80 });
                db.Products.Add(new Product { C = "1003", N = "Pan de agua", Pr = 10, St = 200 });
                Save();
            }
            Text = "Punto de Venta"; ClientSize = new Size(900, 600); StartPosition = FormStartPosition.CenterScreen; Font = new Font("Segoe UI", 10f);
            var tabs = new TabControl(); tabs.Dock = DockStyle.Fill;
            var tv = new TabPage("Venta"); var tp = new TabPage("Productos"); tabs.TabPages.Add(tv); tabs.TabPages.Add(tp);
            Controls.Add(tabs);

            // ----- Venta -----
            lv = LV("Artículo:380", "Precio:110:r", "Cant.:80:r", "Importe:120:r"); lv.Dock = DockStyle.Fill;
            var bot = new Panel(); bot.Dock = DockStyle.Bottom; bot.Height = 100;
            lt = new Label(); lt.Left = 10; lt.Top = 8; lt.Width = 400; lt.Height = 36; lt.Font = new Font("Segoe UI", 18f, FontStyle.Bold); lt.ForeColor = Color.FromArgb(15, 92, 99); bot.Controls.Add(lt);
            lh = new Label(); lh.Left = 10; lh.Top = 56; lh.Width = 400; lh.ForeColor = Color.Gray; bot.Controls.Add(lh);
            Btn(bot, "Más (+1)", 430, 10, 90, delegate { Change(1); });
            Btn(bot, "Menos (-1)", 530, 10, 90, delegate { Change(-1); });
            Btn(bot, "Quitar", 630, 10, 80, delegate { Change(-9999); });
            Btn(bot, "Limpiar", 720, 10, 80, delegate { cart.Clear(); Draw(); });
            var bc = Btn(bot, "COBRAR", 430, 52, 370, delegate { Cobrar(); }); bc.Height = 38;
            q = new TextBox(); q.Dock = DockStyle.Top; q.Font = new Font("Segoe UI", 14f);
            q.KeyDown += delegate (object s, KeyEventArgs e) { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; AddEnter(); } };
            tv.Controls.Add(lv); tv.Controls.Add(bot); tv.Controls.Add(q);

            // ----- Productos -----
            var top = new Panel(); top.Dock = DockStyle.Top; top.Height = 76;
            pc = Txt(top, "Código", 10, 90); pn = Txt(top, "Nombre", 110, 280); pp = Txt(top, "Precio", 400, 100); ps = Txt(top, "Existencia", 510, 90);
            Btn(top, "Guardar", 610, 28, 90, delegate { SaveProd(); });
            Btn(top, "Borrar", 710, 28, 90, delegate { DelProd(); });
            pv = LV("Código:100", "Nombre:400", "Precio:110:r", "Existencia:110:r"); pv.Dock = DockStyle.Fill;
            pv.SelectedIndexChanged += delegate
            {
                if (pv.SelectedItems.Count == 0) return; var p = (Product)pv.SelectedItems[0].Tag;
                pc.Text = p.C; pn.Text = p.N; pp.Text = p.Pr.ToString(CultureInfo.InvariantCulture); ps.Text = p.St.ToString();
            };
            tp.Controls.Add(pv); tp.Controls.Add(top);
            tabs.SelectedIndexChanged += delegate { FillProd(); q.Focus(); };
            FillProd(); Draw();
            Shown += delegate { q.Focus(); };
        }

        void AddEnter()
        {
            string v = q.Text.Trim().ToLower(); if (v.Length == 0) return;
            Product f = Find(v);
            if (f == null) foreach (var p in db.Products) if (p.N.ToLower().Contains(v)) { f = p; break; }
            if (f == null) { MessageBox.Show("Artículo no encontrado."); return; }
            Line l = null; foreach (var x in cart) if (x.P == f) l = x;
            int n = (l != null ? l.Q : 0) + 1;
            if (n > f.St) { MessageBox.Show("Existencia insuficiente de " + f.N + " (" + f.St + ")."); return; }
            if (l != null) l.Q = n; else cart.Add(new Line { P = f, Q = 1 });
            q.Text = ""; Draw();
        }
        void Change(int d)
        {
            if (lv.SelectedIndices.Count == 0) return;
            int i = lv.SelectedIndices[0]; var l = cart[i]; int n = l.Q + d;
            if (n > l.P.St) { MessageBox.Show("Máximo disponible: " + l.P.St); return; }
            if (n <= 0) cart.RemoveAt(i); else l.Q = n;
            Draw();
            if (i < lv.Items.Count) lv.Items[i].Selected = true;
        }
        decimal Total() { decimal t = 0; foreach (var l in cart) t += l.P.Pr * l.Q; return t; }
        void Draw()
        {
            lv.Items.Clear();
            foreach (var l in cart) lv.Items.Add(new ListViewItem(new string[] { l.P.N, M(l.P.Pr), l.Q.ToString(), M(l.P.Pr * l.Q) }));
            lt.Text = "Total: RD$ " + M(Total());
            decimal hoy = 0; foreach (var s in db.Sales) if (s.D.Date == DateTime.Today) hoy += s.Total;
            lh.Text = "Ventas de hoy: RD$ " + M(hoy);
        }
        void Cobrar()
        {
            if (cart.Count == 0) { MessageBox.Show("Agregue artículos a la venta."); return; }
            foreach (var l in cart) if (l.Q > l.P.St) { MessageBox.Show("Existencia insuficiente: " + l.P.N); return; }
            decimal t = Total();
            foreach (var l in cart) l.P.St -= l.Q;
            db.Sales.Add(new Sale { D = DateTime.Now, Total = t }); Save(); cart.Clear(); Draw();
            MessageBox.Show("Venta registrada: RD$ " + M(t), "Listo"); q.Focus();
        }

        void FillProd()
        {
            pv.Items.Clear();
            foreach (var p in db.Products) { var it = new ListViewItem(new string[] { p.C, p.N, M(p.Pr), p.St.ToString() }); it.Tag = p; pv.Items.Add(it); }
        }
        void Clear() { pc.Text = ""; pn.Text = ""; pp.Text = ""; ps.Text = ""; }
        void SaveProd()
        {
            string c = pc.Text.Trim(), n = pn.Text.Trim();
            if (c.Length == 0 || n.Length == 0 || pp.Text.Trim().Length == 0) { MessageBox.Show("Complete código, nombre y precio."); return; }
            var p = Find(c); if (p == null) { p = new Product(); p.C = c; db.Products.Add(p); }
            p.N = n; p.Pr = Num(pp.Text); p.St = (int)Num(ps.Text); Save(); FillProd(); Clear();
        }
        void DelProd()
        {
            var p = Find(pc.Text.Trim()); if (p == null) return;
            if (MessageBox.Show("¿Borrar " + p.N + "?", "Borrar", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            db.Products.Remove(p); Save(); FillProd(); Clear();
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
